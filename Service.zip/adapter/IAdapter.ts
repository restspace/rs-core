/**
 * Basic interface which tags something as being an Adapter class
 */
export class IAdapter {
}