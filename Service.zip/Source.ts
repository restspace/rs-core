export enum Source {
    External, Internal, Outer
}